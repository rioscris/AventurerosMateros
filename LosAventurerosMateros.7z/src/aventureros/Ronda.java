package aventureros;

import java.util.ArrayList;

public class Ronda {
	private ArrayList<Integer> materos;
	private int[] pasajes;
	private int posPava;
	private ArrayList<Integer> eliminados;
	
	public Ronda(ArchivadorRonda archivador) {
		materos = new ArrayList<Integer>();		
		int n = archivador.leerInt();
		for (int i = 0; i < n; i++) {
			materos.add(i+1);
		}
		pasajes = new int[n-1];
		for (int i = 0; i < n-1; i++) {
			pasajes[i] = archivador.leerInt();
		}
		posPava = 0;
	}
	
	public int calcularCebador() {
		posPava = 0;
		for (int ai = 0; ai < pasajes.length; ai++) {
			posPava = (posPava + pasajes[ai])%materos.size();
			eliminarMatero();
		}
		return materos.get(posPava);
	}
	
	public void eliminarMatero() {
		eliminados.add(materos.remove(posPava));
		if(posPava == materos.size())
			posPava = 0;
	}
	
	public ArrayList<Integer> getEliminados() {
		return eliminados;
	}
		
}