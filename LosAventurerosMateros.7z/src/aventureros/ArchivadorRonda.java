package aventureros;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class ArchivadorRonda {
	private Scanner lector;
	private PrintWriter escritor;
	
	public ArchivadorRonda(String nombre) throws FileNotFoundException {
		lector = new Scanner(new File(nombre + ".in"));
		escritor = new PrintWriter(new File(nombre + ".out"));
	}
	
	public int leerInt() {
		return lector.nextInt();
	}
	
	public void cerrar() {
		lector.close();
		escritor.close();
	}
}
