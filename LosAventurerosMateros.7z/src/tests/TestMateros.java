package tests;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import aventureros.ArchivadorRonda;
import aventureros.Ronda;

public class TestMateros {

	private ArchivadorRonda archivador;
	private Ronda ronda;
	
	@Before
	public void setUp() throws FileNotFoundException {
		archivador = new ArchivadorRonda("aventureros");
		ronda = new Ronda(archivador);
	}
	
//	@Test
//	public void queLee() {
//		assertEquals(archivador.lector.nextLine(), "linea test");
//		archivador.escritor.println("salida test");
//	}
//	
	
//	@Test
//	public void queLeeEnteros() {
//		assertEquals(5, archivador.lector.nextInt());
//	}
//	
	
	@Test
	public void queEligeElCebadorCorrecto() {
		assertEquals(3, ronda.calcularCebador());
	}
	
	@After
	public void cerrar() {
		archivador.cerrar();
	}
}
